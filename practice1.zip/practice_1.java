
public class practice_1 {

	public static void main(String[] args) {
		double num = 3.14;
		int num2 = 10;
		
		System.out.println(num + num2);
		System.out.println((int)num + num2);
	}

}
