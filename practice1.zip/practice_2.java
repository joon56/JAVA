
public class practice_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("check each data type size");
		
		System.out.println("Range of byte type : ");
		System.out.println(Byte . MAX_VALUE);
		System.out.println(Byte . MIN_VALUE);
		
		System.out.println("Range of short type : ");
		System.out.println(Short . MAX_VALUE);
		System.out.println(Short . MIN_VALUE);
		
		System.out.println("Range of int type : ");
		System.out.println(Integer . MAX_VALUE);
		System.out.println(Integer . MIN_VALUE);
		
		System.out.println("Range of long type : ");
		System.out.println(Long . MAX_VALUE);
		System.out.println(Long . MIN_VALUE);
		
		System.out.println("Range of char type : ");
		System.out.println((int)Character . MAX_VALUE);
		System.out.println((int)Character . MIN_VALUE);
		
		System.out.println("Range of float type : ");
		System.out.println(Float . MAX_VALUE);
		System.out.println(Float . MIN_VALUE);
		
		System.out.println("Range of double type : ");
		System.out.println(Double . MAX_VALUE);
		System.out.println(Double . MIN_VALUE);

	}

}
